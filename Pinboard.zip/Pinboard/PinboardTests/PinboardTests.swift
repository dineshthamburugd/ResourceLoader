//
//  PinboardTests.swift
//  PinboardTests
//
//  Created by developer on 12/04/17.
//  Copyright © 2017 developer. All rights reserved.
//

import XCTest
@testable import Pinboard

class PinboardTests: XCTestCase {
    
    //ProfileViewController object
    var profileViewController: PBProfileViewController!
    //HomeViewController object
    var homeViewController: PBHomeViewController!
    let testPassed = "Passed"
    let testFailed = "Failed"
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        profileViewController = mainStoryboard.instantiateViewController(withIdentifier: "PBProfileViewController") as! PBProfileViewController
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    /**
     invoking the viewDidLoad in the viewcontroller
     */
    func test_A_viewDidLoad() {
        profileViewController.viewDidLoad()
        XCTAssert(profileViewController.isFirstTimeLoad, testFailed)
        XCTAssertNotNil(profileViewController.getResorceDetails(),testFailed)
    }
    
    /**
     invoking the profileViewController.getAndParseResources() in the viewcontroller
     This  method is used to parse the resources details from the profileViewController
     */
    func test_B_getAndParseResources() {
        profileViewController.getAndParseResources()
        XCTAssertNotNil(profileViewController.arrItems,testFailed)
         XCTAssertEqual(profileViewController.arrItems.count, profileViewController.arrResources.count)
        XCTAssertNotNil(ResourceFileDownloader.sharedInstance().cancelAllDownloads(), testFailed)
        XCTAssertNotNil(profileViewController.selectedResourceForLoading(), testFailed)
    }
    
    /**
     invoking the profileViewController.selectedResourceForLoading() in the viewcontroller
     This  method is used to select the resources for loading in the profileViewController
     */
    func test_C_selectedResourceForLoading() {
         profileViewController.selectedResourceForLoading()
        XCTAssertNotNil(profileViewController.tableView(profileViewController.tblViewProfile, numberOfRowsInSection: profileViewController.arrSelectedItems.count),testFailed)
        let cell = profileViewController.tblViewProfile.dequeueReusableCell(withIdentifier: "profileCell")
        XCTAssertNotNil(cell)
        XCTAssertNotNil(profileViewController.arrSelectedItems, testFailed)
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
