//
//  PinboardHomeTests.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/16/17.
//  Copyright © 2017 developer. All rights reserved.
//

import XCTest

@testable import Pinboard
class PinboardHomeTests: XCTestCase {
    
    //HomeViewController object
    var homeViewController: PBHomeViewController!
    let testPassed = "Passed"
    let testFailed = "Failed"
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        homeViewController = mainStoryboard.instantiateViewController(withIdentifier: "PBHomeViewController") as! PBHomeViewController
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    /**
     invoking the viewDidLoad in the viewcontroller
     */
    func test_A_viewDidLoad() {
        homeViewController.viewDidLoad()
        XCTAssertEqual(homeViewController.title, "Pinboard")
    }
    
    /**
     invoking the homeViewController.SetPinboard() in the viewcontroller
     This  method is used to download the image using a static library.
     */
    func test_B_SetPinboard() {
        let expect = expectation(description: "ImageDownload")
        let imgUrl = "https://dummyimage.com/200x200/000333/d2d4fa.png&text=Hello+Swift!"
        homeViewController.imgUrl = imgUrl
        XCTAssertNotNil(homeViewController.imgUrl,testFailed)
        ResourceFileLoader.sharedInstance().resourceURL(forDownload: imgUrl, withCompletionBlock: { (dictData, error) in
            XCTAssertGreaterThan((dictData?.count)! , 0)
            DispatchQueue.main.async {
                let image : UIImage = UIImage(data: dictData?.object(forKey: imgUrl) as! Data)!
                XCTAssertNotNil(image)
                print("success")
            }
            expect.fulfill()
        })
        
        // Wait for the async request to complete
        waitForExpectations(timeout: 40, handler: nil)
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
