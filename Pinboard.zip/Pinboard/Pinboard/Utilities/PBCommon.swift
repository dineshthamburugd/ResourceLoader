//
//  PBCommon.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration

class PBCommon {
    static let sharedInstance:PBCommon = PBCommon()
    private init() {}
}

var overlayView : UIView?
var progressOverlayView : UIView?

/// Check for network connection.
public class Reachability {
    class func isConnectedToNetwork() -> Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
}

// MARK: - Alert Methods

/// Display alert with title and message
public func showAlertWithOkButtonWithMessage(title text:String , message msg:String, viewController : UIViewController) {
    let alertController = UIAlertController(title: text, message: msg, preferredStyle: .alert)
    let okAction = UIAlertAction(title: AlertButtonText.Ok, style: .cancel) { (action) -> Void in
    }
    alertController.addAction(okAction)
    viewController.present(alertController, animated:true, completion:nil);
}

/** Get the current date from the specific date format ("yyyy-MM-dd").
 - returns: Formatted today's date.
 */
func currentDate() -> String {
    let CD = NSDate()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = DateFormats.dateFormatOne
    dateFormatter.timeZone = NSTimeZone.default
    let date = dateFormatter.string(from: CD as Date)
    return date
}

// MARK: - Progress Indicator Methods

/// Show progress bar with loading text.
func showProgressbar(loadingText text: String) {
    guard let currentMainWindow = UIApplication.shared.keyWindow else {
        return
    }
    showIndicator(overlayTarget: currentMainWindow, loadingText: text)
}

/// Show indicator with overlay target view and loading text.
func showIndicator(overlayTarget : UIView,loadingText: String?) {
    // Clear it first in case it was already shown
    hideProgressbar()
    // Create the overlay
    let overlay = UIView(frame: overlayTarget.frame)
    overlay.alpha = 0.5
    overlay.backgroundColor = UIColor.black
    overlayTarget.addSubview(overlay)
    // Create the progress background view
    let progressFrame = CGRect(x: 0, y: 100, width: 220, height: 90)
    let progressView = UIView(frame: progressFrame)
    progressView.center = overlayTarget.center
    progressView.alpha = 0.9
    progressView.backgroundColor = UIColor.white
    progressView.layer.cornerRadius = 6
    overlayTarget.addSubview(progressView)
    overlayTarget.bringSubview(toFront: progressView)
    // Create and animate the activity indicator
    let indicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    indicator.frame = CGRect(x: (progressFrame.width/2)-10, y: progressFrame.height/4, width: 20, height: 20)
    indicator.startAnimating()
    progressView.addSubview(indicator)
    // Create label
    if let textString = loadingText {
        let label = UILabel()
        label.text = textString
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 12.0)
        label.sizeToFit()
        label.center = CGPoint(x: indicator.center.x, y: indicator.center.y + 25)
        progressView.addSubview(label)
    }
    // Animate the overlay to show
    UIView.beginAnimations(nil, context: nil)
    UIView.setAnimationDuration(0.5)
    UIView.commitAnimations()
    overlayView = overlay
    progressOverlayView = progressView
}

/// Hide progress bar from the views.
func hideProgressbar() {
    if progressOverlayView != nil {
        overlayView?.removeFromSuperview()
        progressOverlayView?.removeFromSuperview()
        overlayView =  nil
        progressOverlayView =  nil
    }
}

