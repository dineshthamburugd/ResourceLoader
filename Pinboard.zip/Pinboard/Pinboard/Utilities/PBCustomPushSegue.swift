//
//  PBCustomPushSegue.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import UIKit

class WACustomPushSegue: UIStoryboardSegue {
    
    // MARK:- Overriding Methods
    override func perform() {
        let sourceViewController = self.source as UIViewController
        let destinationController = self.destination as UIViewController
        sourceViewController.navigationController!.pushViewController(destinationController,animated:true)
    }
}
