//
//  ResourceInMemoryFileCache.h
//  ResourceFileLoader
//
//  Created by dineshthamburu on 4/14/17.
//  Copyright © 2017 dinesh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ResourceFileInfo.h"

@interface ResourceInMemoryFileCache : NSObject

//Stores a file
- (void)storeFile:(id)aFile MIMEType:(NSString *)mimeType fileURL:(NSString *)anURL;

//Retrieves a file
- (ResourceFileInfo *)retrieveFile:(NSString *)anURL;

//Removes the cache
- (void)removeCache;

@end
