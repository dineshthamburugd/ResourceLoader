//
//  ResourceFileDownloader.h
//  ResourceFileLoader
//
//  Created by dineshthamburu on 4/14/17.
//  Copyright © 2017 dinesh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ResourceFileDownloader : NSObject

//Create instance for ResourceFileDownloader
+(ResourceFileDownloader *)sharedInstance;

//downloads a file
- (void)startDownload:(NSString *)urlToDownloadFile forKey:(NSString *)aKey completionBlock:(void(^)(id downloadedData, NSString* mimeType, NSString *key))completionBlock;

//cancels a download using the key
- (void)cancelDownload:(NSString *)forKey;

//Cancels all the downloads
- (void)cancelAllDownloads;


@end
