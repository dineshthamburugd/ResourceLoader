//
//  ResourceFileInfo.h
//  ResourceFileLoader
//
//  Created by dineshthamburu on 4/14/17.
//  Copyright © 2017 dinesh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ResourceFileInfo : NSObject

//represents the file to cache
@property (nonatomic, strong) id aFile;

//represents the dowloadanle link/location of the file
@property (nonatomic, strong) NSString *urlString;

//represents the mime type of the downloaded file.
@property (nonatomic, strong) NSString *mimeType;

//custom initilizer of the class
- (instancetype)initWithObject:(id)inputFile MIMEType:(NSString *)mimeType fileURL:(NSString *)anURL;

@end
