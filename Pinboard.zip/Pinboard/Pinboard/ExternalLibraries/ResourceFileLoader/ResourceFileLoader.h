//
//  ResourceFileLoader.h
//  ResourceFileLoader
//
//  Created by dineshthamburu on 4/14/17.
//  Copyright © 2017 dinesh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ResourceFileLoader : NSObject

//Create instance for ResourceFileDownloader
+(ResourceFileLoader *)sharedInstance;

////download callback for a file
- (void)resourceURLForDownload:(NSString *)strUrl withCompletionBlock:(void(^)(NSMutableDictionary *dictResources, NSError *error)) completionBlock;

@end
