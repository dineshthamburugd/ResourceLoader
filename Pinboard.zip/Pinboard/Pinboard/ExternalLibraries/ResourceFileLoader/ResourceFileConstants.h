//
//  ResourceFileConstants.h
//  ResourceFileLoader
//
//  Created by dineshthamburu on 4/14/17.
//  Copyright © 2017 dinesh. All rights reserved.
//

#ifndef ResourceFileConstants_h
#define ResourceFileConstants_h


#endif /* ResourceFileConstants_h */

//The max capacity of the cache. This will evict images,if the configured buffer size exceeds
#define CACHE_MAXIMUM_CAPACITY 1024 * 1024 * 500 //500 Mb
