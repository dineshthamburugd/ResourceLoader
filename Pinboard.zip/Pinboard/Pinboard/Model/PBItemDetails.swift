//
//  PBItemDetails.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import Foundation

// Data model for downloaded resources.
struct PBItemDetails {
    var userName: String?
    var imgSmallUrl: String?
    var imgMediumUrl: String?
    var imgLargeUrl: String?
}
