//
//  PBHomeViewController.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import UIKit

class PBHomeViewController: UIViewController {
    
    // MARK: - Properties
    var arrImageResources = [[String : AnyObject]]()
    var imgItemDetails: PBItemDetails!
    var downloadedImg:UIImage!
    var imgUrl:String!
    
    @IBOutlet weak var baseView: UIView!
    
    @IBOutlet weak var imgTileMedium: UIImageView!
    
    @IBOutlet weak var imgTileSmall: UIImageView!
    
    @IBOutlet weak var imgTileLarge: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Pinboard"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.getResources()
    }
    
    // MARK: - Other Methods
    func setPinboard(urlString:String!) {
        if Reachability.isConnectedToNetwork() == true{
            let downloadUrl = urlString!
            ResourceFileLoader .sharedInstance().resourceURL(forDownload: imgUrl, withCompletionBlock: { (dictData, error) in
                print(dictData ?? "")
                if (dictData?.count ?? 0)! > 0{
                    print ((self.imgUrl)!)
                    DispatchQueue.main.async {
                        self.downloadedImg = UIImage(data: dictData?.object(forKey: downloadUrl) as! Data)!
                        self.imgTileSmall.image = self.downloadedImg
                        self.imgTileMedium.image = self.downloadedImg
                        self.imgTileLarge.image = self.downloadedImg
                        self.animatePinboardView()
                        
                    }
                }
            })
        }else{
            showAlertWithOkButtonWithMessage(title: AlertMessages.Title, message: AlertMessages.NoNetworkConnection, viewController: self)
        }
    }
    
    func getResources() {
        for index in 0..<3 {
            switch index {
            case 0:
                imgUrl = (self.imgItemDetails.imgSmallUrl)!
            case 1:
                imgUrl = (self.imgItemDetails.imgMediumUrl)!
            case 2:
                imgUrl = (self.imgItemDetails.imgLargeUrl)!
            default:
                imgUrl = (self.imgItemDetails.imgSmallUrl)!
            }
            setPinboard(urlString: imgUrl)
        }
    }
    
    func animatePinboardView() {
        UIView.animate(withDuration: 0.5, animations: {
            let transformScaled = CGAffineTransform.identity.scaledBy(x: 1.5, y: 1.5)
            self.baseView.transform = transformScaled
        }) { (finished) in
            // once finished first animation
            // start second animation
            if finished {
                // animate scaling by 1.0, 1.0
                UIView.animate(withDuration: 0.5, animations: {
                    let transformScaled = CGAffineTransform.identity.scaledBy(x: 1.0, y: 1.0)
                    self.baseView.transform = transformScaled
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - UIButton Actions
    
    @IBAction func btnBackTapped(sender: AnyObject) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
