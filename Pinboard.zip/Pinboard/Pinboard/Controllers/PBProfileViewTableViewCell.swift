//
//  PBProfileViewTableViewCell.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import UIKit

class PBProfileViewTableViewCell: UITableViewCell {

    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
