//
//  PBProfileViewController.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import UIKit

class PBProfileViewController: UIViewController {
    
    // MARK: - Properties
    var serviceManager:PBServiceManager?
    var itemDetails: PBItemDetails!
    var arrResources = [[String : AnyObject]]()
    var arrItems = [PBItemDetails]()
    var arrSelectedItems = [PBItemDetails]()
    
    var itemDisplayCount = 10
    var reachedEndOfItems = false
    var isFirstTimeLoad = false
    var itemsCount:Int = 0
    
    @IBOutlet weak var lblEmptyMessage: UILabel?
    @IBOutlet weak var tblViewProfile: UITableView!
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Last update: \(currentDate())")
        refreshControl.addTarget(self, action: #selector(PBProfileViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        
        return refreshControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationItem.title = "Users"
        self.navigationController?.navigationBar.isTranslucent = false
        itemDetails    = PBItemDetails()
        isFirstTimeLoad = true
        lblEmptyMessage?.isHidden = false
        self.view.bringSubview(toFront: self.lblEmptyMessage!)
        tblViewProfile.addSubview(self.refreshControl)
        showProgressbar(loadingText:AlertMessages.Loading)
        self.getResorceDetails()
    }
    
    // MARK: - Other Methods
    func getResorceDetails() {
        if Reachability.isConnectedToNetwork() == true{
            serviceManager = PBServiceManager.sharedInstance;
            serviceManager?.callWebserviceForResources(strUrl: ServiceURL.resourceDetailsURL, completionBlock: { (arrResponse, error) in
                if(arrResponse.count > 0){
                    print("Response\(arrResponse)")
                    DispatchQueue.main.async {
                        self.arrResources = (arrResponse as? [[String: AnyObject]])!
                        self.getAndParseResources()
                        hideProgressbar()
                    }
                }
            })
        }else{
            showAlertWithOkButtonWithMessage(title: AlertMessages.Title, message: AlertMessages.NoNetworkConnection, viewController: self)
        }
    }
    
    // For parsing the resource details.
    func getAndParseResources() {
        arrItems.removeAll()
        for dictValue in arrResources{
            if let dictUserDetails = dictValue["user"] as? [String: AnyObject]{
                if let dictImgDetails = dictUserDetails["profile_image"] as? [String: AnyObject]{
                    let imageUrl = dictImgDetails["small"] as? String
                    itemDetails.imgSmallUrl = imageUrl
                    itemDetails.imgMediumUrl = dictImgDetails["medium"] as? String
                    itemDetails.imgLargeUrl = dictImgDetails["large"] as? String
                }
                let name = dictUserDetails["name"] as? String
                itemDetails.userName = name
                arrItems.append(itemDetails!)
            }
        }
    }
    
    // Pull to refresh method.
    
    func handleRefresh(_ refreshControl: UIRefreshControl) {
        getResorceDetails()
        DispatchQueue.main.async {
            if self.isFirstTimeLoad{
                self.itemsCount = self.itemDisplayCount
                self.isFirstTimeLoad = false
            }
            self.selectedResourceForLoading()
            refreshControl.endRefreshing()
        }
    }
    
    // Method for selecting the initial count for loading of data.
    func selectedResourceForLoading(){
        arrSelectedItems.removeAll()
        for index in 0 ..< arrItems.count {
            if index < itemsCount{
                arrSelectedItems.append(arrItems[index])
            }
            if index >= itemsCount-1{
                break;
            }
        }
        
        if arrSelectedItems.count > 0{
            lblEmptyMessage?.isHidden = true;
            tblViewProfile.reloadData()
        }else{
            lblEmptyMessage?.isHidden = false;
            self.view.bringSubview(toFront: self.lblEmptyMessage!)
        }
        ResourceFileDownloader.sharedInstance().cancelAllDownloads()
    }
    
    // Method for lazy loading of the data.
    func loadMore() {
        guard !self.reachedEndOfItems else {
            return
        }
        selectedResourceForLoading()
        itemsCount = itemsCount + itemDisplayCount
        if arrItems.count <= itemsCount{
            itemsCount = arrItems.count
            reachedEndOfItems = true
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UINavigation Actions
    func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "profileToPinboard") {
            let homeVC:PBHomeViewController = (segue.destination as? PBHomeViewController)!
            homeVC.imgItemDetails = itemDetails;
        }
    }
}
// MARK: -

extension PBProfileViewController : UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate {
    
    // MARK:- UITableview Delegate and Datasource Methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSelectedItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "profileCell", for: indexPath) as! PBProfileViewTableViewCell
        itemDetails = arrSelectedItems[indexPath.row]
        let imgUrl = (self.itemDetails.imgSmallUrl)!
        ResourceFileLoader.sharedInstance().resourceURL(forDownload: imgUrl, withCompletionBlock: { (dictData, error) in
            print(dictData ?? "")
            if (dictData?.count ?? 0)! > 0{
                DispatchQueue.main.async {
                    let image : UIImage = UIImage(data: dictData?.object(forKey: imgUrl) as! Data)!
                    cell.imgProfile.image = image
                }
            }
        })
        cell.lblName.text = (itemDetails.userName)!
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        itemDetails = arrSelectedItems[indexPath.row]
        self.performSegue(withIdentifier: "profileToPinboard", sender:self)
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        if targetContentOffset.pointee.y < scrollView.contentOffset.y {
            // scroll up
            itemsCount = itemsCount + itemDisplayCount
            self.loadMore()
        } else {
            // scroll down
        }
    }
}
