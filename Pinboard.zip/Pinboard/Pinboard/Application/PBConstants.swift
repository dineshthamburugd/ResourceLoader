//
//  PBConstants.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import Foundation
import UIKit


struct ServiceURL{
    static let resourceDetailsURL =  "http://pastebin.com/raw/wgkJgazE"
}

struct AlertMessages {
    static let Title = "Pinboard"
    static let NoNetworkConnection = "Sorry, no Internet connectivity detected. Please reconnect and try again"
    static let Loading = "Please wait..."
}

struct AlertButtonText {
    static let Ok = "Ok"
    static let Cancel = "Cancel"
}

struct DateFormats {
    static let dateFormatOne = "MMM d, h:mm a"
}


func UIColorFromHex(rgbValue: UInt) -> UIColor {
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0))
}
