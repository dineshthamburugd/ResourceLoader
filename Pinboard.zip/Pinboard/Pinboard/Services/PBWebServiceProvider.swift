//
//  PBWebServiceProvider.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import UIKit

class PBWebServiceProvider: NSObject {
    
    // MARK:- Properties
    
    static let sharedInstance = PBWebServiceProvider()
    
    //Remote service for downloads a file
    func callRemoteService(urlPath:String?,completionBlock:((NSArray, NSError?)->())?) {
        
        // set up the session
        let defaultSession = URLSession(configuration: URLSessionConfiguration.default)
        var dataTask: URLSessionDataTask?
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
        }
        
        let serviceuUrl: NSURL = NSURL(string: urlPath!)!
        
        dataTask = defaultSession.dataTask(with: serviceuUrl as URL) { data, response, error in
            DispatchQueue.main.async {
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
            
            if let error = error {
                print(error.localizedDescription)
            } else if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode == 200 {
                    do {
                        guard let jsonResult = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSArray else {
                            return
                        }
                        completionBlock!(jsonResult,nil)
                    } catch {
                        print("Error: \(error.localizedDescription)")
                    }
                }
            }
        }
        dataTask?.resume()
    }
}




