//
//  PBServiceManager.swift
//  Pinboard
//
//  Created by dineshthamburu on 4/15/17.
//  Copyright © 2017 developer. All rights reserved.
//

import UIKit

class PBServiceManager: NSObject {
    
    // MARK:- Properties
    static let sharedInstance = PBServiceManager()
    
    // MARK:- Network Methods
    func callWebserviceForResources(strUrl:String?, completionBlock:((NSArray, NSError?)->())?) {
        PBWebServiceProvider.sharedInstance.callRemoteService(urlPath: strUrl) { (arrValues:NSArray, error:NSError?) -> () in
            completionBlock!(arrValues,error)
        }
    }
}
